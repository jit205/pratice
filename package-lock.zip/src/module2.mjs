    const a='jittam';
    const b='meet';
    const c='jash';
    export default c;
    export {a,b};