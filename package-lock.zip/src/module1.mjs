    import c,{a,b} from './module2.mjs'
    console.log(c);
    console.log(b); 
    console.log(a);